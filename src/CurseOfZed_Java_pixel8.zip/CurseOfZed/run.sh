#!/bin/bash
echo "Compiling Curse of Zed..."
mkdir -p out
javac -encoding UTF-8 src/CurseOfZed.java -d out
if [ $? -ne 0 ]; then
    echo "Compilation failed. Make sure Java JDK is installed."
    exit 1
fi
echo "Launching..."
java -cp out CurseOfZed
